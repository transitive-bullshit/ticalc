//Routines by Sasume.

//void DrawPattern_RPLC(short x asm("%d0"),short y asm("%d1"),short repet asm("%d2"),short offset asm("%d3"),char motif asm("%d4"),void *dest asm("%a0"));
void DrawPattern_MASK(short x asm("%d0"),short y asm("%d1"),short repet asm("%d2"),short offset asm("%d3"),char motif,char mask,void *dest asm("%a0"))__attribute__((stkparm));
