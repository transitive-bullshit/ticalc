/// Header File
// Created 6/1/2004; 3:38:12 PM

//Constants

#define GAME_VERSION				("SlimeBall 1.00  ")
#define player_weight				(.2)
#define ball_weight 				(.06)
#define ball_diameter 			(8)
#define player_width				(28)
#define START0 							(-10)
#define START1 							(-11)
#define num_of_point_to_win	(6)
#define ball_max_vector			(2)
#define wall_tip						(2)
#define magic_key 					(23)
//frame coord
#define frame_coord_left	 	(3)
#define frame_coord_right 	(156)
#define frame_coord_up			(3)
#define frame_coord_down		(92)
//slime segmentation #:
#define ss1 								(4)
#define ss2 								(14)
#define ss3 								(32-14)
#define ss4 								(32-4)
//slime segmentation # vector:
#define ss1vx 							(-0.8)
#define ss2vx 							(-0.6)
#define ss3vx 							(0.6)
#define ss4vx 							(0.8)
#define ss5vx 							(0)			//(in the middle)
#define ss1vy 							(-0.8)
#define ss2vy 							(-1.2)
#define ss3vy 							(-1.2)
#define ss4vy 							(-0.8)
#define ss5vy 							(-1.5) 	//(in the middle)
//ball out of bound
#define boob_left		 				(3)
#define boob_right 					(150)
#define boob_down 					(84)
#define boob_up							(2)
//initial positions
#define ip_ball_x 					(40)
#define ip_ball_y 					(20)
#define ip_ball_vx 					(0)
#define ip_ball_vy 					(0)
#define ip_player_left_x		(10)
#define ip_player_right_x		(110)
#define ip_player_y					(75)
#define ip_player_vy				(100)
#define ip_wall_x						(80)
#define ip_wall_y						(80)
#define ip_wall_vx					(.2)
#define ip_wall_vy					(.3)
#define ip_wall_lenght			(4)
//players movement vectors
#define pmv_horizontal			(2)
#define pmv_vertical				(-3)
//link related
#define host_num 						(0)
#define join_num 						(1)

#define qqq printf("asfdsdf");while(!_keytest(RR_ENTER)){};while(_keytest(RR_ENTER)){}; //debug
enum ReturnValue	{RETURN_TO_MENU,EXIT_NOW,CONTINUE};
enum LinkConstants	{Link_mode = 4,Vs_IA_mode,Same_calc_mode};
enum DialogConstants	{pref_brick=10,pref_beach,pref_blank,pref_motionless,pref_vertical,pref_horizontal,pref_vert_and_hori,
pref_jupiter,pref_earth,pref_moon,pref_zero_grav,pref_on,pref_off, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9};
enum pref_type {pbckgnd,pwall,pgravity,pexplo,pspeed};
