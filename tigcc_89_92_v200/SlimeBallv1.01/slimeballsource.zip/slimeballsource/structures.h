// Header File
// Created 7/28/2004; 3:27:49 PM

typedef struct
{
	int rx;
	int ry;
	float x;
	float y;
	float vy;
	char move;
	int wins;
	char pref;
}PLAYER_STRUCT;


typedef struct
{
	int rx;
	int ry;
	float x;
	float y;
	float vx;
	float vy;
}BALL_STRUCT;

typedef struct
{
	float x;
	float y;
	float vx;
	float vy;
}WALL_STRUCT;


typedef struct {
	short int option[6];
	int magic;
	int random_seed;
} PREF_STRUCT;
