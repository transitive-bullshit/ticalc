// C Source File
// Created 7/28/2004; 3:26:39 PM

#include <tigcclib.h>
#include "structures.h"

//All of these functions comes from Kevin Kofler's Backgammon.
//(modified to fit SlimeBall of course!)


/************************************************
*		Routine that returns the handle to the file
************************************************/
HANDLE get_handle() {
	SYM_ENTRY *sym=SymFindPtr($(slimesav),0);
	HANDLE handle;
	if (sym) {
		if (sym->flags.bits.archived) {
			if (!EM_moveSymFromExtMem($(slimesav),HS_NULL)) return(H_NULL);
		}
		handle=HeapRealloc(sym->handle,47);
		sym=SymFindPtr($(slimesav),0);
	} else {
		HSym hsym=SymAdd($(slimesav));
		//if (!*(unsigned long *)&hsym) return(H_NULL);
		handle=HeapAlloc(47);
		if (handle)
		sym=DerefSym(hsym);
		else
		SymDel($(slimesav));
	}
	if (!handle) return(H_NULL);
	sym->handle=handle;
	return(handle);     
}

/************************************************
*		writes the prefs...
************************************************/

void write_data(PREF_STRUCT *s) {
	HANDLE h = get_handle();
	if (!h)
	return;
	short *fptr=HeapDeref(h);
	*fptr=45;
	memcpy(fptr+1,s,sizeof(PREF_STRUCT));
  memcpy(fptr+20,(char [7]){0,'p','r','e','f',0,OTH_TAG},7);
	return;
}

/************************************************
*		reads the prefs...
************************************************/

void read_data(PREF_STRUCT *s) {
	HANDLE h = get_handle();
	if (!h)
	return;
	short *fptr=HeapDeref(h);
  memcpy(s,fptr+1,sizeof(PREF_STRUCT));
}
